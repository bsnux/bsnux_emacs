# Script test for completition

import string
s=""
